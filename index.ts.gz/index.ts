
// first ts file
const sum = (a : number, b: number):number =>{
    return a + b
}

console.log(sum(5, 7))


const names: string[] = ["my", "names", "string"]

/*let killName = (name: string) => string 

killName = (name)=>{
    return name.toUpp
}   */

const killName = (name: string):string =>{
   return name.toUpperCase() 
}   
