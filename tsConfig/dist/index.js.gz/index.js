"use strict";
const printName = (name) => {
    console.log(name);
};
printName("somzzy");
