

const printName = ( name: string ): void =>{
     console.log(name)
}

printName("somzzy")
