/* const printName = (name: string): void => {
     console.log(name)
 }

 printName("changed")

 const calcPrice = (price: number):number=>{
  const PERCENT = 0.18 
  return +(price + (price * PERCENT).toFixed(1))
 }

 console.log(calcPrice(1280))

 let year: number = 2022

 console.log(year)
 year = 0b100 
 console.log(year)
 year = 0X100
 console.log(year)
 year = 0O100
 console.log(year)

 //never type 
 
 const sum = (a: number, b: number) =>{
     return (a + b)
 }  */

 // enums 
 
/*enum weekdays {
    monday = 0,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
    sunday = weekdays.monday - 1
}

console.log(weekdays)
console.log(weekdays.friday)   */

// ,Object
//
/*type Fruit = {
    name: string,
    taste: string,
    color: string,
    allSeason: boolean
}

const fruit:Fruit = {
      name: "mango",
      taste: "sweet",
      color: "green" ,
      allSeason: false
  }

  console.log(typeof fruit.name)      */

  //Array 
//
//const fruit: string[] = ["mango", "tomatoes", "orange"]

 //Tuple 
//
/*let color: [number,number,number] = [255,255,255]
 color.push(244)    */ 


 // Union Type 
  /*const printId = (id: number | string): string | number =>{
      if(typeof id === "string")
          return id.toUpperCase()
      return id
  }


  // Types Alias & interface 
  // 
  //

interface Fruit  {
    name: string,
    taste: string,
    color: string,
    allSeason: boolean
}

interface Orange extends Fruit {
    price: number
}

const fruits:Orange = {
      name: "mango",
      taste: "sweet",
      color: "green" ,
      allSeason: false,
      price: 20,
  }  

  // extending type aliases 


type Fruites = {
    name: string,
    taste: string,
    color: string,
    allSeason: boolean
    price ?: number | null
}

type Mango = Fruites & {
    price ?: number | null
}
const fruit: Mango = {
      name: "mango",
      taste: "sweet",
      color: "green" ,
      allSeason: false,
  }


  const getPrice = (price: number, discount: number = 0) => {
      return price + discount
  }

  console.log(getPrice(fruits.price))

  // Class 
  //
  class Coordinates {

      protected x : number 
      protected y: number 
       constructor(x: number, y: number){
           this.x = x; 
           this.y = y
       }
  }
  class MyCoordinate extends Coordinates{
       get X() {
           return this.x
       }
        set X(x: number){
         this.x = x  
       }
  }
  const point = new MyCoordinate(47,50) 

  console.log(point.X)


  // static properties 
  //
   

  class Perishable{
     readonly  price: number; 
     protected static count: number = 0
      constructor(price : number){
         this.price = price 
         Perishable.count++
      }
         static getCount():number{
             return Perishable.count
         }
  }

  const mango = new Perishable(20)

  const apple = new Perishable(80) 

  console.log(Perishable.getCount)       */

  // More On interfaces 
  // 
     interface Fruit {
         name: string,
        readonly price: number,
         color ?: string

     }

  const getName = (fruit: Fruit): string =>{
      
   return `${fruit.name} is have a price of ${fruit.price}`
  }

   class MyFruit implements Fruit{
      name: string 
      price: number 
      constructor(name: string, price: number){
          this.name = name 
          this.price = price
      }
   }
  


   // Generic Types 
   function getRandomArray<T>  (arr: T[]):T {
      const Randomindex = Math.floor(Math.random() * arr.length)
       return arr[Randomindex]
   }

   getRandomArray(["y","x","z"]) 

   //Generic Constraint 

   type person = {
      firstName: string   
   }

   function getPerson<T extends person> (data: T){
       return data
   }

   const details = {
       lastName: "somzzy" ,
       firstName: "chuks"
   }

   console.log(getPerson(details))

   function getElement<O extends object, K extends keyof O> (obj:O , key:K){
       return obj[key]
   }

getElement(details, "lastName")
