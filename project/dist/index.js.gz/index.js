"use strict";
/* const printName = (name: string): void => {
     console.log(name)
 }

 printName("changed")

 const calcPrice = (price: number):number=>{
  const PERCENT = 0.18
  return +(price + (price * PERCENT).toFixed(1))
 }

 console.log(calcPrice(1280))

 let year: number = 2022

 console.log(year)
 year = 0b100
 console.log(year)
 year = 0X100
 console.log(year)
 year = 0O100
 console.log(year)

 //never type
 
 const sum = (a: number, b: number) =>{
     return (a + b)
 }  */
const getName = (fruit) => {
    return `${fruit.name} is have a price of ${fruit.price}`;
};
class MyFruit {
    name;
    price;
    constructor(name, price) {
        this.name = name;
        this.price = price;
    }
}
// Generic Types 
function getRandomArray(arr) {
    const Randomindex = Math.floor(Math.random() * arr.length);
    return arr[Randomindex];
}
getRandomArray(["y", "x", "z"]);
function getPerson(data) {
    return data;
}
const details = {
    lastName: "somzzy",
    firstName: "chuks"
};
console.log(getPerson(details));
function getElement(obj, key) {
    return obj[key];
}
getElement(details, "lastName");
