interface Fruit {
    name: string;
    readonly price: number;
    color?: string;
}
declare const getName: (fruit: Fruit) => string;
declare class MyFruit implements Fruit {
    name: string;
    price: number;
    constructor(name: string, price: number);
}
declare function getRandomArray<T>(arr: T[]): T;
declare type person = {
    firstName: string;
};
declare function getPerson<T extends person>(data: T): T;
declare const details: {
    lastName: string;
    firstName: string;
};
declare function getElement<O extends object, K extends keyof O>(obj: O, key: K): O[K];
