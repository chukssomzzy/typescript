// first ts file
var sum = function (a, b) {
    return a + b;
};
console.log(sum(5, 7));


let name: string[] = ["name", 'my']
